import { useState } from "react";

const Selecciona = ({valor}) => {
	const [basePrice, setBasePrice] = useState(6);
	const options = [
		{ price: 6, label: "Margarita" },
		{ price: 7, label: "Vegetal" },
		{ price: 8, label: "Carbonara" },
		{ price: 9, label: "Barbacoa" },
	];
	return (
		<div>
			<select
				value={basePrice}
				onChange={(e) => {
					setBasePrice(e.target.value);
				console.log(basePrice);
				}}
			>
				{options.map((option) => (
					<option key={option.price} value={option.price}>
						{option.label}
					</option>
				))}
			</select>
		</div>
	);
};

export default Selecciona;
