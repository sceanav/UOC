import { useState } from "react";
import Selecciona from "./Components/Selecciona";

const App = () => {
	const [price, setPrice] = useState(6);
	const [isChecked, setIsChecked] = useState(false);

	

	const sizes = [
		{ priceCorrection: -2, label: "Pequeña" },
		{ priceCorrection: 0, label: "Mediana" },
		{ priceCorrection: 2, label: "Grande" },
	];
  
	return (
		<div>
			<p>Seleccione el tipo de pizza: </p>

		<Selecciona preciobase={setPrice}></Selecciona>
       
			<form className="radio">
				<h4>Tamaños</h4>
				{sizes.map((mySize) => (
					<div key={mySize.label}>
						<input
							type="radio"
							name="radio"
							value={Number(price) + Number(mySize.priceCorrection)}
							onChange={(e) => setPrice(e.target.value)}
						/>
						{mySize.label}
					</div>
				))}
			</form>
			<div>
				<label htmlFor="">
					<p>Introduce Código Promocional: </p>
					<input
						type="text"
						onChange={(e) => {
							if (e.target.value === "esfamiao") {
								setPrice(price * 0.6);
							}
						}}
					/>
				</label>
				<div>
					<label htmlFor="">
						Entrega a domicilio:
						<input
							type="checkbox"
							checked={isChecked}
							onChange={(e) => {
								if (!isChecked) {
									setPrice(Number(price) + 4);
								} else {
									setPrice(Number(price) - 4);
								}
								setIsChecked(!isChecked);
							}}
						/>
					</label>
				</div>
			</div>
			<div>
				<h2>Tu precio es: {price}</h2>
			</div>
		</div>
	);
};

export default App;
